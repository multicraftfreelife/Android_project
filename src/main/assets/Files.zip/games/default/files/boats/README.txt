Minetest 0.4 mod: boats
=======================
by PilzAdam, slightly modified for NeXt
changed by TenPlus1 to add some new features
 - boat is destroyed when crashing (drops 3 wood)
 - boat turns faster
 - used model from ds_rowboat mod

License of source code:
-----------------------
WTFPL

License of media (textures and sounds):
---------------------------------------
WTFPL

Authors of media files:
-----------------------
textures: Zeg9
model: thetoon and Zeg9, modified by PavelS(SokolovPavel)
