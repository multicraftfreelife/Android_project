
local path = minetest.get_modpath("mobs_monster")

-- Monsters

dofile(path .. "/spider.lua") -- AspireMint
dofile(path .. "/zombie.lua") -- Blockmen
dofile(path .. "/skeleton.lua") -- Blockmen
