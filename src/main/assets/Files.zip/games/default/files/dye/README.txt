Minetest 0.4 mod: dye
======================

See init.lua for documentation.

License of source code and media files:
---------------------------------------
Copyright (C) 2012 Perttu Ahola (celeron55) <celeron55@gmail.com>

This program is free software. It comes without any warranty, to
the extent permitted by applicable law. You can redistribute it
and/or modify it under the terms of the Do What The Fuck You Want
To Public License, Version 2, as published by Sam Hocevar. See
http://sam.zoy.org/wtfpl/COPYING for more details.

