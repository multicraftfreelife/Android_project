Wool mod for Minetest

by TenPlus1

Yep, it's a simple replacement for the wool mod that allows you to dye any
wool any colour including white, and I've also added a wool sound when walking
on top of the wool blocks to replace the leaves sound.

Textures are from Gambit's PixelBox texture pack.

Sound is from freeSFX.co.uk and has a creative-commons license
